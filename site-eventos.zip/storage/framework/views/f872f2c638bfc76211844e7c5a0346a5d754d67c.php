

<?php $__env->startSection('title', 'Produtos'); ?>

<?php $__env->startSection('content'); ?>

<h1>Pagina de Contatos</h1>
<label for="contato">Contato: (62) 98307-7232</label>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\ProjetoLaravel\site-eventos\resources\views/contatos.blade.php ENDPATH**/ ?>
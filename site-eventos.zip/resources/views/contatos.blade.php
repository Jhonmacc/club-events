@extends('layouts.main')

@section('title', 'Produtos')

@section('content')

<h1>Pagina de Contatos</h1>
<label for="contato">Contato: (62) 98307-7232</label>


@endsection
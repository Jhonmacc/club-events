@extends('layouts.main')
@section('title', 'Macc Eventos')

@section('content')

        <h1>Eventos todos os dias</h1>
        <img src="/img/evento1.jpg" alt="Banner">




@endsection
